import json
import csv
import shutil
import numpy as np
from pathlib import Path

def compute_cost(parcel, factors):
    class_id = parcel['bldg_class']
    quality = parcel['quality']
    sqft = float(parcel['sqft'])
    locality = parcel['locality']
    year_built = int(parcel['year_built'])
    current_year = 2025

    base_cost = factors['baseCosts'].get(class_id, {}).get(quality)
    locality_adj = factors['localityAdjustments'].get(locality, 1.0)
    curve = factors['depreciationCurves'].get(class_id, [])

    age = current_year - year_built
    depreciation = 1.0
    for i in range(1, len(curve)):
        y0, d0 = curve[i-1]
        y1, d1 = curve[i]
        if y0 <= age <= y1:
            t = (age - y0) / (y1 - y0)
            depreciation = d0 + t * (d1 - d0)
            break
    return sqft * base_cost * locality_adj * depreciation if base_cost else 0.0

def load_parcels(path):
    with open(path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        return list(reader)

def load_factors(path):
    with open(path, 'r') as f:
        return json.load(f)

def benchmark(factors, parcels):
    scores = [compute_cost(p, factors) for p in parcels]
    mean = np.mean(scores)
    return np.std(scores) / mean

def run_guard(factor_path, parcel_path):
    backup_path = factor_path.with_name(factor_path.stem + ".bak.json")
    shutil.copy(factor_path, backup_path)

    with open(factor_path, 'r') as f:
        current = json.load(f)
    with open(backup_path, 'r') as f:
        previous = json.load(f)
    parcels = load_parcels(parcel_path)

    current_cov = benchmark(current, parcels)
    previous_cov = benchmark(previous, parcels)

    print(f"🔍 Current CoV:  {current_cov:.4f}")
    print(f"🧾 Previous CoV: {previous_cov:.4f}")

    if current_cov > previous_cov * 1.01:
        print("❌ Regression detected — rolling back to previous factor set.")
        shutil.copy(backup_path, factor_path)
    else:
        print("✅ Current factor set passes CoV threshold. No rollback needed.")

if __name__ == "__main__":
    run_guard(Path("../../data/factors-2025.json"), Path("../../sample/benton_parcels_demo.csv"))
