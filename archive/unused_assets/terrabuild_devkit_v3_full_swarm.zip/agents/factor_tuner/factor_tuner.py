import json
import csv
import numpy as np
from pathlib import Path

# Load cost factor table
def load_factors(path):
    with open(path, 'r') as f:
        return json.load(f)

# Load parcel CSV
def load_parcels(path):
    with open(path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        return list(reader)

# Simple evaluator: compute cost estimate
def compute_cost(parcel, factors):
    class_id = parcel['bldg_class']
    quality = parcel['quality']
    sqft = float(parcel['sqft'])
    locality = parcel['locality']
    year_built = int(parcel['year_built'])
    current_year = 2025

    base_cost = factors['baseCosts'].get(class_id, {}).get(quality)
    locality_adj = factors['localityAdjustments'].get(locality, 1.0)
    curve = factors['depreciationCurves'].get(class_id, [])

    # Linear interpolate depreciation
    age = current_year - year_built
    depreciation = 1.0
    for i in range(1, len(curve)):
        y0, d0 = curve[i-1]
        y1, d1 = curve[i]
        if y0 <= age <= y1:
            t = (age - y0) / (y1 - y0)
            depreciation = d0 + t * (d1 - d0)
            break
    return sqft * base_cost * locality_adj * depreciation if base_cost else 0.0

# Run factor sweep to optimize CoV
def sweep_and_update(factor_path, parcel_path):
    with open(factor_path, "r") as f:
        factors = json.load(f)
    parcels = load_parcels(parcel_path)

    original_scores = [compute_cost(p, factors) for p in parcels]
    avg = np.mean(original_scores)
    cov = np.std(original_scores) / avg

    print(f"Original CoV: {cov:.4f}")

    best_cov = cov
    original_factor = factors['baseCosts']['R']['2']
    best_factor = original_factor

    for delta in np.linspace(-0.05, 0.05, 11):
        test_factor = round(original_factor * (1 + delta), 2)
        factors['baseCosts']['R']['2'] = test_factor
        scores = [compute_cost(p, factors) for p in parcels]
        mean = np.mean(scores)
        temp_cov = np.std(scores) / mean
        print(f"Delta {delta:+.2%} → CoV: {temp_cov:.4f}")
        if temp_cov < best_cov:
            best_cov = temp_cov
            best_factor = test_factor

    if best_factor != original_factor:
        print(f"🎯 Updating baseCosts['R']['2'] from {original_factor} → {best_factor}")
        factors['baseCosts']['R']['2'] = best_factor
        with open(factor_path, "w") as f:
            json.dump(factors, f, indent=2)
    else:
        print("✅ No improvement found. No update applied.")

if __name__ == "__main__":
    factor_file = Path("../../data/factors-2025.json")
    parcel_file = Path("../../sample/benton_parcels_demo.csv")
    sweep_and_update(factor_file, parcel_file)
