"""
Simulates zoning/ADU policy impacts across a parcel roll.
"""

import csv
from pathlib import Path

def simulate_adu_effect(parcel_path):
    print("🏘️ Simulating ADU policy impact on parcel valuations...")
    with open(parcel_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if int(row['sqft']) < 800:
                print(f"Parcel {row['parcel_id']}: likely ADU-eligible, valuation boost +12%")

if __name__ == "__main__":
    simulate_adu_effect(Path('../../sample/benton_parcels_demo.csv'))
