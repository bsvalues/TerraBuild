"""
Trains local depreciation curves from permit/appraisal data.
"""

import json
import numpy as np
from pathlib import Path

def train_curve(permit_data):
    # placeholder: real training would use ML regression or spline fitting
    return [[0, 0], [30, 0.25], [80, 1.0]]

def update_curve(factor_path):
    with open(factor_path, 'r') as f:
        factors = json.load(f)
    new_curve = train_curve([])  # TODO: replace with actual permit data ingest
    factors['depreciationCurves']['R'] = new_curve
    with open(factor_path, 'w') as f:
        json.dump(factors, f, indent=2)
    print("🧠 Trained and updated depreciation curve for Residential class.")

if __name__ == "__main__":
    update_curve(Path('../../data/factors-2025.json'))
