"""
Generates a line-item justification for each parcel cost estimate.
"""

        import json
        import csv
        from pathlib import Path

        def generate_argument(parcel_row, factor_table):
            return {
                "parcel_id": parcel_row['parcel_id'],
                "base_cost": factor_table['baseCosts'].get(parcel_row['bldg_class'], {}).get(parcel_row['quality'], "N/A"),
                "locality_adj": factor_table['localityAdjustments'].get(parcel_row['locality'], "N/A"),
                "depreciation_curve": factor_table['depreciationCurves'].get(parcel_row['bldg_class'], []),
                "note": "This cost breakdown aligns with current county cost factors and standard age-adjustment models."
            }

        def run_boe_justifier(parcel_path, factor_path):
            with open(factor_path) as f:
                factors = json.load(f)
            with open(parcel_path, newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    arg = generate_argument(row, factors)
                    print(f"📄 Justification for parcel {arg['parcel_id']}:
", json.dumps(arg, indent=2), "
")

        if __name__ == "__main__":
            run_boe_justifier(Path('../../sample/benton_parcels_demo.csv'), Path('../../data/factors-2025.json'))
