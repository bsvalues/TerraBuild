#!/usr/bin/env bash
set -euo pipefail

echo "🧠 Launching TerraBuild swarm agents..."

echo "🔧 Running FactorTuner..."
python3 agents/factor_tuner/factor_tuner.py

echo "📈 Running CurveTrainer..."
python3 agents/curve_trainer/curve_trainer.py

echo "🏘️ Running ScenarioAgent..."
python3 agents/scenario_agent/scenario_agent.py

echo "🧾 Running BOEArguer..."
python3 agents/boe_arguer/boe_arguer.py

echo "🔁 Running BenchmarkGuard..."
python3 agents/benchmark_guard/benchmark_guard.py

echo "✅ Swarm run complete."
