import React, { useState } from 'react';

export default function App() {
  const [csvFile, setCsvFile] = useState<File | null>(null);

  const handleUpload = async () => {
    if (!csvFile) return;
    const formData = new FormData();
    formData.append("file", csvFile);
    const res = await fetch("http://localhost:4000/api/import/csv", {
      method: "POST",
      body: formData,
    });
    const text = await res.text();
    alert("Import finished: " + text);
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">TerraBuild Cost Calculator</h1>
      <input
        type="file"
        accept=".csv"
        onChange={(e) => setCsvFile(e.target.files?.[0] ?? null)}
        className="mb-4"
      />
      <button
        onClick={handleUpload}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        Upload CSV
      </button>
    </div>
  );
}
