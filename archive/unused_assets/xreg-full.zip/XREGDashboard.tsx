
// XREGDashboard.tsx
import React from 'react';
import PredictionExplainer from './PredictionExplainer';
import AgentFeed from './AgentFeed';

export default function XREGDashboard() {
  return (
    <div className="min-h-screen bg-gray-50 p-6 space-y-8">
      <h1 className="text-3xl font-bold text-center">XREG: Explainable Regression Console</h1>
      <div className="flex flex-col lg:flex-row gap-6 justify-center items-start">
        <div className="flex-1">
          <PredictionExplainer />
        </div>
        <div className="w-full lg:w-[350px]">
          <AgentFeed />
        </div>
      </div>
    </div>
  );
}
