
# XREG: Explainable Regression Console

This module is the second core component of the TerraBuild platform, showcasing explainable regression with real-time AI agent collaboration.

## Components

- `PredictionExplainer.tsx`: Shows how a cost prediction was calculated, with SHAP-style reasoning.
- `AgentFeed.tsx`: Displays log messages and insights from AI agents responsible for valuation, model testing, and explanation.
- `XREGDashboard.tsx`: Full dashboard that combines the explainer and the agent console.
- `sample_shap_output.json`: Sample input/output for development or mocking backend data.

## Usage

Import `XREGDashboard` into your main view and use Tailwind CSS to style it. Connect backend models to feed actual agent logs and explanation data.

## License

MIT – Built for TerraFusion™
