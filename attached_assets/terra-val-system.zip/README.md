
# TerraBuild: AI-Driven Cost Valuation Platform

TerraBuild is a next-generation cost valuation system that makes every decision transparent, explainable, and defensible.

This repository includes:

- ✅ Full React UI (`ValuationDashboard`)
- ✅ Real FastAPI backend (validate, re-run, export)
- ✅ Docker-ready deployment
- ✅ Audit trail via session UUIDs
- ✅ Export as JSON or PDF

## 🚀 Running the Full Stack Locally

### Backend (API)
```bash
cd backend
docker build -t terrabuild-api .
docker run -p 5001:5001 terrabuild-api
```

### Frontend
Make sure `.env` points to `http://localhost:5001`

```bash
npm install
npm run dev
```

## 📂 Repo Structure

| Folder | Purpose |
|--------|---------|
| `backend/` | FastAPI service |
| `frontend/` | React + Tailwind UI |
| `matrix_sessions/` | Local session storage |
| `exports/` | Exported audit files |

MIT License — 2025 TerraFusion™
