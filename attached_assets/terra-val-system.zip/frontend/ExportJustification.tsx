
// ExportJustification.tsx
import React, { useState } from 'react';

export default function ExportJustification() {
  const [sessionId, setSessionId] = useState("");

  const download = (type) => {
    if (!sessionId) return alert("Provide session ID first");
    const ext = type === "pdf" ? "pdf" : "json";
    const url = `http://localhost:5001/api/export/${ext}/${sessionId}`;
    window.open(url, "_blank");
  };

  return (
    <div className="p-4 bg-white shadow rounded space-y-2">
      <h3 className="text-lg font-semibold">🧾 Export Justification</h3>
      <input
        type="text"
        placeholder="Enter session ID..."
        className="w-full border p-2 text-sm rounded"
        value={sessionId}
        onChange={(e) => setSessionId(e.target.value)}
      />
      <button
        className="mt-3 px-4 py-2 bg-green-600 text-white rounded w-full"
        onClick={() => download("pdf")}
      >
        ⬇️ Download PDF Summary
      </button>
      <button
        className="mt-2 px-4 py-2 bg-gray-700 text-white rounded w-full"
        onClick={() => download("json")}
      >
        ⬇️ Download Full JSON
      </button>
    </div>
  );
}
