
# MCP Matrix Upload Module

This GitHub-ready module integrates a transparent, agent-powered matrix upload interface into the Benton County MCP DevOps Kit.

## Features

✅ Upload Excel-based cost matrix files  
✅ Trigger Replit AI agents to validate and process files  
✅ Display agent health and feedback in real-time  
✅ Render parsed data and insights for review

## Files Included

- `MatrixUploadInterface.tsx` – Main React UI component
- `useMCPAgents.ts` – React hook to invoke agents
- `agents.json` – Normalized agent registry
- `Matrix_UX_Spec.md` – UX specification
- `ReplitAgentPipeline.yaml` – Agent workflow definition

## Setup

1. Drop all files into your React/Next.js client folder.
2. Ensure the MCP backend routes `/mcp/agent/run` are operational.
3. Connect UI to API using `useMCPAgents`.
4. Deploy and test.

MIT License.
    