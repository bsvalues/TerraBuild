#!/usr/bin/env bash
set -euo pipefail
FILE=${1:-sample/parcel_data.csv}
echo "Importing $FILE …"
curl -F "file=@$FILE" http://localhost:4000/api/import/csv
