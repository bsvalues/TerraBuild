# TerraBuild Developer Kit 🛠️

This kit lets you spin up TerraBuild—including the Cost Factor engine,
sample data, and React UI shell—in under a minute.

## Quick Start

```bash
git clone <your-fork>
cd terrabuild-devkit
docker compose up -d               # API at http://localhost:4000
pnpm --filter client dev           # UI dev server at http://localhost:5173
```

## Contents

Path                  | Purpose
----------------------|---------------------------------------
Dockerfile            | Multi‑stage build for API server
docker-compose.yml    | Postgres + API containers
data/factors-2025.json| Example cost‑factor table (editable)
sample/parcel_data.csv| Ten‑row CSV for import smoke test
scripts/import_sample.sh | CLI wrapper: imports the sample CSV
client/               | React Cost Calculator UI shell

## Environment Variables

Var           | Default
--------------|--------------------------------------------
DATABASE_URL  | postgres://terrabuild:terrabuild@db:5432/terrabuild
PORT          | 4000

## Updating Cost Factor Tables

Edit `data/factors-2026.json` with new locality, class, quality rows.

Bump `FACTOR_TABLE_VERSION` env var.

Restart the API container—no code change!

## License

Apache 2.0 for starter kit. Factor tables remain your proprietary IP.
