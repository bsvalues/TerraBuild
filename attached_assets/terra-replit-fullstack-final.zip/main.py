
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
import terrabuild_api_sessions as api_routes

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routes from original API file
app.include_router(api_routes.app.routes[0].router)

# Serve frontend
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
