
# TerraBuild: Smart Cost Valuation Platform

This repository contains the full-featured, transparent, and AI-enhanced valuation interface built as part of the TerraFusion ecosystem.

## 📦 Features

- ✅ Agent-powered insights (SHAP-style explanation)
- ✅ Editable matrix view with rerun logic
- ✅ Timeline-based valuation tracking
- ✅ Scenario comparison (baseline, RSMeans, permits)
- ✅ Exportable justification package
- ✅ Real-time agent logs and insight feeds

## 🚀 Getting Started

1. Clone this repo.
2. Run `npm install` to get dependencies.
3. Place your backend agent API endpoints at `/api/mcp/agent/run` or mock them.
4. Run `npm run dev`.

## 🔧 Components

| File | Purpose |
|------|---------|
| `ValuationDashboard.tsx` | Full integrated UI shell |
| `EditableMatrixView.tsx` | Inline cost editor |
| `InsightSummaryCard.tsx` | Agent result summaries |
| `ValuationTimelineChart.tsx` | Year-over-year valuation |
| `ValueScenarioCompare.tsx` | Multi-perspective value views |
| `ExportJustification.tsx` | Audit/export panel |
| `AgentFeed.tsx` | Live agent log stream |

MIT License — © 2025 TerraFusion
