
// MatrixExplorer.tsx
import React, { useState } from 'react';

const mockData = {
  matrix_id: "2025-R3-East",
  region: "Eastern",
  building_type: "Manufactured Home",
  original_value: 105.00,
  external_data: {
    rsmeans: 118.42,
    permits: 111.75,
    comps: 113.25
  },
  agent_weighting: {
    rsmeans: 0.5,
    permits: 0.3,
    comps: 0.2
  },
  final_adjusted_value: 114.16,
  agent_recommendation: "Override with weighted value from external sources."
};

export default function MatrixExplorer() {
  const [accepted, setAccepted] = useState(false);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-4">
      <h1 className="text-xl font-bold">Matrix Data Review</h1>
      <div className="grid grid-cols-2 gap-6">

        <div className="bg-gray-50 border p-4 rounded shadow-sm">
          <h2 className="font-semibold">Original Matrix Value</h2>
          <p><strong>ID:</strong> {mockData.matrix_id}</p>
          <p><strong>Region:</strong> {mockData.region}</p>
          <p><strong>Building Type:</strong> {mockData.building_type}</p>
          <p><strong>Original Value:</strong> ${mockData.original_value.toFixed(2)}</p>
        </div>

        <div className="bg-blue-50 border p-4 rounded shadow-sm">
          <h2 className="font-semibold">External Data Sources</h2>
          <p>RSMeans: ${mockData.external_data.rsmeans.toFixed(2)}</p>
          <p>Permits: ${mockData.external_data.permits.toFixed(2)}</p>
          <p>Comps: ${mockData.external_data.comps.toFixed(2)}</p>
        </div>

        <div className="bg-yellow-50 border p-4 rounded shadow-sm col-span-2">
          <h2 className="font-semibold">Agent Merge & Recommendation</h2>
          <p><strong>Final Adjusted Value:</strong> ${mockData.final_adjusted_value.toFixed(2)}</p>
          <p><strong>Reasoning:</strong> {mockData.agent_recommendation}</p>
          <p><strong>Weights:</strong></p>
          <ul className="ml-4 list-disc">
            <li>RSMeans: {mockData.agent_weighting.rsmeans * 100}%</li>
            <li>Permits: {mockData.agent_weighting.permits * 100}%</li>
            <li>Comps: {mockData.agent_weighting.comps * 100}%</li>
          </ul>

          {!accepted ? (
            <button onClick={() => setAccepted(true)} className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
              ✅ Accept Agent Recommendation
            </button>
          ) : (
            <div className="mt-4 text-green-700 font-semibold">✔️ Accepted and applied</div>
          )}
        </div>
      </div>
    </div>
  );
}
