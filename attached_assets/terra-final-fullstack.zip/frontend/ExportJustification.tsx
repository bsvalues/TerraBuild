
import React from 'react';

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:5001";

export default function ExportJustification({ sessionId = "" }) {
  const handleExport = (type) => {
    if (!sessionId) return alert("Missing session ID.");
    const ext = type === "pdf" ? "pdf" : "json";
    const url = `${API_BASE}/api/export/${ext}/${sessionId}`;
    window.open(url, "_blank");
  };

  return (
    <div className="p-4 bg-white shadow rounded space-y-2">
      <h3 className="text-lg font-semibold">🧾 Export Justification</h3>
      <p className="text-sm text-gray-600">Session: <code>{sessionId || "None"}</code></p>
      <button
        className="mt-3 px-4 py-2 bg-green-600 text-white rounded w-full"
        onClick={() => handleExport("pdf")}
      >
        ⬇️ Download PDF Summary
      </button>
      <button
        className="mt-2 px-4 py-2 bg-gray-700 text-white rounded w-full"
        onClick={() => handleExport("json")}
      >
        ⬇️ Download Full JSON
      </button>
    </div>
  );
}
