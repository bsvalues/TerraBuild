
import React, { useEffect, useState } from 'react';

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:5001";

export default function AgentFeed() {
  const [insights, setInsights] = useState([]);

  useEffect(() => {
    const fetchInsights = async () => {
      const res = await fetch(`${API_BASE}/api/get_insights`);
      const data = await res.json();
      setInsights(data);
    };
    fetchInsights();
  }, []);

  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="text-lg font-semibold">🧠 Agent Feed</h3>
      <ul className="mt-2 text-sm text-gray-700 space-y-2">
        {insights.map((entry, idx) => (
          <li key={idx} className="border-b pb-1">
            <strong>{entry.agent}</strong>: {entry.message}
            <div className="text-xs text-gray-500">{entry.timestamp}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
