
from fastapi import FastAPI, Request
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict
from datetime import datetime
import os, json, uuid

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_DIR = "./matrix_sessions"
os.makedirs(DATA_DIR, exist_ok=True)

class MatrixRow(BaseModel):
    id: int
    building_type: str
    base_cost: float

class MatrixPayload(BaseModel):
    fileName: str
    data: List[MatrixRow]

def save_session(data, session_id):
    path = os.path.join(DATA_DIR, f"{session_id}.json")
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

@app.post("/api/validate_matrix")
def validate_matrix(payload: MatrixPayload):
    session_id = str(uuid.uuid4())
    issues = [row for row in payload.data if row.base_cost < 100]
    session_data = {
        "id": session_id,
        "file": payload.fileName,
        "created_at": datetime.now().isoformat(),
        "rows": [row.dict() for row in payload.data],
        "issues": len(issues)
    }
    save_session(session_data, session_id)
    return {
        "session_id": session_id,
        "valid": len(issues) == 0,
        "issues_found": len(issues),
        "message": "Validation complete.",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/session/{session_id}")
def get_session(session_id: str):
    path = os.path.join(DATA_DIR, f"{session_id}.json")
    if not os.path.exists(path):
        return {"error": "Session not found."}
    with open(path) as f:
        return json.load(f)


from fastapi.responses import JSONResponse, FileResponse
from fastapi import FastAPI
import os, json

DATA_DIR = "./matrix_sessions"
EXPORT_DIR = "./exports"
os.makedirs(EXPORT_DIR, exist_ok=True)

app = FastAPI()

@app.get("/api/export/json/{session_id}")
def export_json(session_id: str):
    path = os.path.join(DATA_DIR, f"{session_id}.json")
    if not os.path.exists(path):
        return {"error": "Session not found."}
    return FileResponse(path, media_type='application/json', filename=f"{session_id}.json")

@app.get("/api/export/pdf/{session_id}")
def export_pdf(session_id: str):
    path = os.path.join(DATA_DIR, f"{session_id}.json")
    if not os.path.exists(path):
        return {"error": "Session not found."}

    with open(path) as f:
        session = json.load(f)

    # Simulate PDF content as plain text export
    pdf_path = os.path.join(EXPORT_DIR, f"{session_id}.txt")
    with open(pdf_path, "w") as f:
        f.write(f"Session ID: {session_id}\n")
        f.write(f"File: {session.get('file')}\n")
        f.write(f"Issues Found: {session.get('issues')}\n")
        f.write(f"Rows: {len(session.get('rows', []))} records\n\n")
        for row in session.get("rows", []):
            f.write(f"Row {row['id']} - {row['building_type']}: ${row['base_cost']}\n")

    return FileResponse(pdf_path, media_type='text/plain', filename=f"{session_id}.pdf")
