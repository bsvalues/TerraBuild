
# TerraBuild Dev Environment

## 🧠 Purpose
This dev setup uses mock API endpoints to simulate agent behavior, regression reruns, and insight feeds.

## 🚀 Running Locally

### 1. Start Mock Agent API

```bash
npm install express cors
node mock-agent-api.js
```

### 2. Set API base in your frontend `.env`

```
REACT_APP_API_BASE=http://localhost:5001
```

### 3. Use Components

Drop these into your React project (TypeScript + Tailwind preferred). Use `ValuationDashboard.tsx` as your main route.

## 🧪 Endpoints Emulated
| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/matrix/validate` | Validates uploaded matrix |
| `POST` | `/api/matrix/re-run` | Reprocesses after edits |
| `GET`  | `/api/agent/insights` | Fetches agent messages |

All results are simulated.

## 📂 Structure

- `ValuationDashboard.tsx`: Full UI integration
- Individual modules:
  - `EditableMatrixView`
  - `AgentFeed`
  - `InsightSummaryCard`
  - `ValuationTimelineChart`
  - `ExportJustification`
  - `ValueScenarioCompare`

MIT License — TerraFusion™
