
const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/matrix/validate', (req, res) => {
  res.json({
    success: true,
    message: "Matrix schema validated successfully",
    flaggedRows: 0,
    sheet: req.body.fileName || "uploaded_matrix.xlsx"
  });
});

app.post('/api/matrix/re-run', (req, res) => {
  res.json({
    reRunComplete: true,
    insight: "Agent re-analysis complete. No anomalies detected.",
    adjustedValues: [
      { id: 1, new_value: 126.2 },
      { id: 2, new_value: 135.1 }
    ]
  });
});

app.get('/api/agent/insights', (req, res) => {
  res.json([
    {
      agent: "InquisitorAgent",
      message: "Validation passed: all regions match schema.",
      timestamp: "Just now"
    },
    {
      agent: "VisualizerAgent",
      message: "Eastern R3 saw a 12% increase vs 2022. Flagged 2 rows.",
      timestamp: "1 minute ago"
    },
    {
      agent: "ExplainerAgent",
      message: "Living area and roof type are driving 65% of variance.",
      timestamp: "2 minutes ago"
    }
  ]);
});

app.listen(5001, () => console.log("🔧 Mock API running on port 5001"));
